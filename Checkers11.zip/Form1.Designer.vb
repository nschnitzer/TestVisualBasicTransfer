﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.mnuCheckers = New System.Windows.Forms.MenuStrip()
        Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuClose = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuStart = New System.Windows.Forms.ToolStripMenuItem()
        Me.btn2 = New System.Windows.Forms.Button()
        Me.pb1 = New System.Windows.Forms.PictureBox()
        Me.btn3 = New System.Windows.Forms.Button()
        Me.btn4 = New System.Windows.Forms.Button()
        Me.btn5 = New System.Windows.Forms.Button()
        Me.btn6 = New System.Windows.Forms.Button()
        Me.btn7 = New System.Windows.Forms.Button()
        Me.btn8 = New System.Windows.Forms.Button()
        Me.pb2 = New System.Windows.Forms.PictureBox()
        Me.pb3 = New System.Windows.Forms.PictureBox()
        Me.pb4 = New System.Windows.Forms.PictureBox()
        Me.pb5 = New System.Windows.Forms.PictureBox()
        Me.pb6 = New System.Windows.Forms.PictureBox()
        Me.pb7 = New System.Windows.Forms.PictureBox()
        Me.pb8 = New System.Windows.Forms.PictureBox()
        Me.btn15 = New System.Windows.Forms.Button()
        Me.btn14 = New System.Windows.Forms.Button()
        Me.btn13 = New System.Windows.Forms.Button()
        Me.btn12 = New System.Windows.Forms.Button()
        Me.btn11 = New System.Windows.Forms.Button()
        Me.btn10 = New System.Windows.Forms.Button()
        Me.btn9 = New System.Windows.Forms.Button()
        Me.btn16 = New System.Windows.Forms.Button()
        Me.btn32 = New System.Windows.Forms.Button()
        Me.btn31 = New System.Windows.Forms.Button()
        Me.btn30 = New System.Windows.Forms.Button()
        Me.btn29 = New System.Windows.Forms.Button()
        Me.btn28 = New System.Windows.Forms.Button()
        Me.btn27 = New System.Windows.Forms.Button()
        Me.btn26 = New System.Windows.Forms.Button()
        Me.btn25 = New System.Windows.Forms.Button()
        Me.btn24 = New System.Windows.Forms.Button()
        Me.btn23 = New System.Windows.Forms.Button()
        Me.btn22 = New System.Windows.Forms.Button()
        Me.btn21 = New System.Windows.Forms.Button()
        Me.btn20 = New System.Windows.Forms.Button()
        Me.btn19 = New System.Windows.Forms.Button()
        Me.btn18 = New System.Windows.Forms.Button()
        Me.btn17 = New System.Windows.Forms.Button()
        Me.btn48 = New System.Windows.Forms.Button()
        Me.btn47 = New System.Windows.Forms.Button()
        Me.btn46 = New System.Windows.Forms.Button()
        Me.btn45 = New System.Windows.Forms.Button()
        Me.btn44 = New System.Windows.Forms.Button()
        Me.btn43 = New System.Windows.Forms.Button()
        Me.btn42 = New System.Windows.Forms.Button()
        Me.btn41 = New System.Windows.Forms.Button()
        Me.btn40 = New System.Windows.Forms.Button()
        Me.btn39 = New System.Windows.Forms.Button()
        Me.btn38 = New System.Windows.Forms.Button()
        Me.btn37 = New System.Windows.Forms.Button()
        Me.btn36 = New System.Windows.Forms.Button()
        Me.btn35 = New System.Windows.Forms.Button()
        Me.btn33 = New System.Windows.Forms.Button()
        Me.btn64 = New System.Windows.Forms.Button()
        Me.btn63 = New System.Windows.Forms.Button()
        Me.btn62 = New System.Windows.Forms.Button()
        Me.btn61 = New System.Windows.Forms.Button()
        Me.btn60 = New System.Windows.Forms.Button()
        Me.btn59 = New System.Windows.Forms.Button()
        Me.btn58 = New System.Windows.Forms.Button()
        Me.btn57 = New System.Windows.Forms.Button()
        Me.btn56 = New System.Windows.Forms.Button()
        Me.btn55 = New System.Windows.Forms.Button()
        Me.btn54 = New System.Windows.Forms.Button()
        Me.btn53 = New System.Windows.Forms.Button()
        Me.btn52 = New System.Windows.Forms.Button()
        Me.btn51 = New System.Windows.Forms.Button()
        Me.btn50 = New System.Windows.Forms.Button()
        Me.btn34 = New System.Windows.Forms.Button()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.mnuCheckers.SuspendLayout()
        CType(Me.pb1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'mnuCheckers
        '
        Me.mnuCheckers.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile})
        Me.mnuCheckers.Location = New System.Drawing.Point(0, 0)
        Me.mnuCheckers.Name = "mnuCheckers"
        Me.mnuCheckers.Size = New System.Drawing.Size(714, 24)
        Me.mnuCheckers.TabIndex = 0
        Me.mnuCheckers.Text = "$safeprojectname$ Menu Strip"
        '
        'mnuFile
        '
        Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuClose, Me.mnuStart})
        Me.mnuFile.Name = "mnuFile"
        Me.mnuFile.Size = New System.Drawing.Size(37, 20)
        Me.mnuFile.Text = "File"
        '
        'mnuClose
        '
        Me.mnuClose.Name = "mnuClose"
        Me.mnuClose.Size = New System.Drawing.Size(103, 22)
        Me.mnuClose.Text = "Close"
        '
        'mnuStart
        '
        Me.mnuStart.Name = "mnuStart"
        Me.mnuStart.Size = New System.Drawing.Size(103, 22)
        Me.mnuStart.Text = "Start"
        '
        'btn2
        '
        Me.btn2.BackColor = System.Drawing.Color.White
        Me.btn2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn2.Enabled = False
        Me.btn2.Location = New System.Drawing.Point(221, 60)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(55, 42)
        Me.btn2.TabIndex = 3
        Me.btn2.UseVisualStyleBackColor = False
        '
        'pb1
        '
        Me.pb1.Location = New System.Drawing.Point(53, 7)
        Me.pb1.Name = "pb1"
        Me.pb1.Size = New System.Drawing.Size(23, 17)
        Me.pb1.TabIndex = 5
        Me.pb1.TabStop = False
        '
        'btn3
        '
        Me.btn3.BackColor = System.Drawing.Color.Black
        Me.btn3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn3.Enabled = False
        Me.btn3.Location = New System.Drawing.Point(273, 60)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(55, 42)
        Me.btn3.TabIndex = 7
        Me.btn3.UseVisualStyleBackColor = False
        '
        'btn4
        '
        Me.btn4.BackColor = System.Drawing.Color.White
        Me.btn4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn4.Enabled = False
        Me.btn4.Location = New System.Drawing.Point(322, 60)
        Me.btn4.Name = "btn4"
        Me.btn4.Size = New System.Drawing.Size(55, 42)
        Me.btn4.TabIndex = 8
        Me.btn4.UseVisualStyleBackColor = False
        '
        'btn5
        '
        Me.btn5.BackColor = System.Drawing.Color.Black
        Me.btn5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn5.Enabled = False
        Me.btn5.Location = New System.Drawing.Point(374, 60)
        Me.btn5.Name = "btn5"
        Me.btn5.Size = New System.Drawing.Size(55, 42)
        Me.btn5.TabIndex = 9
        Me.btn5.UseVisualStyleBackColor = False
        '
        'btn6
        '
        Me.btn6.BackColor = System.Drawing.Color.White
        Me.btn6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn6.Enabled = False
        Me.btn6.Location = New System.Drawing.Point(425, 60)
        Me.btn6.Name = "btn6"
        Me.btn6.Size = New System.Drawing.Size(55, 42)
        Me.btn6.TabIndex = 10
        Me.btn6.UseVisualStyleBackColor = False
        '
        'btn7
        '
        Me.btn7.BackColor = System.Drawing.Color.Black
        Me.btn7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn7.Enabled = False
        Me.btn7.Location = New System.Drawing.Point(474, 60)
        Me.btn7.Name = "btn7"
        Me.btn7.Size = New System.Drawing.Size(55, 42)
        Me.btn7.TabIndex = 11
        Me.btn7.UseVisualStyleBackColor = False
        '
        'btn8
        '
        Me.btn8.BackColor = System.Drawing.Color.White
        Me.btn8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn8.Enabled = False
        Me.btn8.Location = New System.Drawing.Point(528, 60)
        Me.btn8.Name = "btn8"
        Me.btn8.Size = New System.Drawing.Size(56, 42)
        Me.btn8.TabIndex = 12
        Me.btn8.UseVisualStyleBackColor = False
        '
        'pb2
        '
        Me.pb2.Location = New System.Drawing.Point(93, 7)
        Me.pb2.Name = "pb2"
        Me.pb2.Size = New System.Drawing.Size(23, 17)
        Me.pb2.TabIndex = 13
        Me.pb2.TabStop = False
        '
        'pb3
        '
        Me.pb3.Location = New System.Drawing.Point(125, 7)
        Me.pb3.Name = "pb3"
        Me.pb3.Size = New System.Drawing.Size(23, 17)
        Me.pb3.TabIndex = 14
        Me.pb3.TabStop = False
        '
        'pb4
        '
        Me.pb4.Location = New System.Drawing.Point(157, 7)
        Me.pb4.Name = "pb4"
        Me.pb4.Size = New System.Drawing.Size(23, 17)
        Me.pb4.TabIndex = 15
        Me.pb4.TabStop = False
        '
        'pb5
        '
        Me.pb5.Location = New System.Drawing.Point(196, 7)
        Me.pb5.Name = "pb5"
        Me.pb5.Size = New System.Drawing.Size(23, 17)
        Me.pb5.TabIndex = 16
        Me.pb5.TabStop = False
        '
        'pb6
        '
        Me.pb6.Location = New System.Drawing.Point(236, 7)
        Me.pb6.Name = "pb6"
        Me.pb6.Size = New System.Drawing.Size(23, 17)
        Me.pb6.TabIndex = 17
        Me.pb6.TabStop = False
        '
        'pb7
        '
        Me.pb7.Location = New System.Drawing.Point(265, 7)
        Me.pb7.Name = "pb7"
        Me.pb7.Size = New System.Drawing.Size(23, 17)
        Me.pb7.TabIndex = 18
        Me.pb7.TabStop = False
        '
        'pb8
        '
        Me.pb8.Location = New System.Drawing.Point(298, 7)
        Me.pb8.Name = "pb8"
        Me.pb8.Size = New System.Drawing.Size(23, 17)
        Me.pb8.TabIndex = 19
        Me.pb8.TabStop = False
        '
        'btn15
        '
        Me.btn15.BackColor = System.Drawing.Color.White
        Me.btn15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn15.Enabled = False
        Me.btn15.Location = New System.Drawing.Point(475, 96)
        Me.btn15.Name = "btn15"
        Me.btn15.Size = New System.Drawing.Size(55, 42)
        Me.btn15.TabIndex = 26
        Me.btn15.UseVisualStyleBackColor = False
        '
        'btn14
        '
        Me.btn14.BackColor = System.Drawing.Color.Black
        Me.btn14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn14.Enabled = False
        Me.btn14.Location = New System.Drawing.Point(423, 96)
        Me.btn14.Name = "btn14"
        Me.btn14.Size = New System.Drawing.Size(55, 42)
        Me.btn14.TabIndex = 25
        Me.btn14.UseVisualStyleBackColor = False
        '
        'btn13
        '
        Me.btn13.BackColor = System.Drawing.Color.White
        Me.btn13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn13.Enabled = False
        Me.btn13.Location = New System.Drawing.Point(374, 96)
        Me.btn13.Name = "btn13"
        Me.btn13.Size = New System.Drawing.Size(55, 42)
        Me.btn13.TabIndex = 24
        Me.btn13.UseVisualStyleBackColor = False
        '
        'btn12
        '
        Me.btn12.BackColor = System.Drawing.Color.Black
        Me.btn12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn12.Enabled = False
        Me.btn12.Location = New System.Drawing.Point(323, 96)
        Me.btn12.Name = "btn12"
        Me.btn12.Size = New System.Drawing.Size(55, 42)
        Me.btn12.TabIndex = 23
        Me.btn12.UseVisualStyleBackColor = False
        '
        'btn11
        '
        Me.btn11.BackColor = System.Drawing.Color.White
        Me.btn11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn11.Enabled = False
        Me.btn11.Location = New System.Drawing.Point(271, 96)
        Me.btn11.Name = "btn11"
        Me.btn11.Size = New System.Drawing.Size(55, 42)
        Me.btn11.TabIndex = 22
        Me.btn11.UseVisualStyleBackColor = False
        '
        'btn10
        '
        Me.btn10.BackColor = System.Drawing.Color.Black
        Me.btn10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn10.Enabled = False
        Me.btn10.Location = New System.Drawing.Point(222, 96)
        Me.btn10.Name = "btn10"
        Me.btn10.Size = New System.Drawing.Size(55, 42)
        Me.btn10.TabIndex = 21
        Me.btn10.UseVisualStyleBackColor = False
        '
        'btn9
        '
        Me.btn9.BackColor = System.Drawing.Color.White
        Me.btn9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn9.Enabled = False
        Me.btn9.Location = New System.Drawing.Point(21, 203)
        Me.btn9.Name = "btn9"
        Me.btn9.Size = New System.Drawing.Size(55, 42)
        Me.btn9.TabIndex = 20
        Me.btn9.UseVisualStyleBackColor = False
        '
        'btn16
        '
        Me.btn16.BackColor = System.Drawing.Color.Black
        Me.btn16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn16.Enabled = False
        Me.btn16.Location = New System.Drawing.Point(529, 96)
        Me.btn16.Name = "btn16"
        Me.btn16.Size = New System.Drawing.Size(55, 42)
        Me.btn16.TabIndex = 34
        Me.btn16.Text = "Button1"
        Me.btn16.UseVisualStyleBackColor = False
        '
        'btn32
        '
        Me.btn32.BackColor = System.Drawing.Color.Black
        Me.btn32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn32.Enabled = False
        Me.btn32.Location = New System.Drawing.Point(528, 168)
        Me.btn32.Name = "btn32"
        Me.btn32.Size = New System.Drawing.Size(55, 42)
        Me.btn32.TabIndex = 66
        Me.btn32.Text = "Button1"
        Me.btn32.UseVisualStyleBackColor = False
        '
        'btn31
        '
        Me.btn31.BackColor = System.Drawing.Color.White
        Me.btn31.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn31.Enabled = False
        Me.btn31.Location = New System.Drawing.Point(475, 168)
        Me.btn31.Name = "btn31"
        Me.btn31.Size = New System.Drawing.Size(55, 42)
        Me.btn31.TabIndex = 58
        Me.btn31.UseVisualStyleBackColor = False
        '
        'btn30
        '
        Me.btn30.BackColor = System.Drawing.Color.Black
        Me.btn30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn30.Enabled = False
        Me.btn30.Location = New System.Drawing.Point(423, 168)
        Me.btn30.Name = "btn30"
        Me.btn30.Size = New System.Drawing.Size(55, 42)
        Me.btn30.TabIndex = 57
        Me.btn30.UseVisualStyleBackColor = False
        '
        'btn29
        '
        Me.btn29.BackColor = System.Drawing.Color.White
        Me.btn29.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn29.Enabled = False
        Me.btn29.Location = New System.Drawing.Point(374, 168)
        Me.btn29.Name = "btn29"
        Me.btn29.Size = New System.Drawing.Size(55, 42)
        Me.btn29.TabIndex = 56
        Me.btn29.UseVisualStyleBackColor = False
        '
        'btn28
        '
        Me.btn28.BackColor = System.Drawing.Color.Black
        Me.btn28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn28.Enabled = False
        Me.btn28.Location = New System.Drawing.Point(323, 168)
        Me.btn28.Name = "btn28"
        Me.btn28.Size = New System.Drawing.Size(55, 42)
        Me.btn28.TabIndex = 55
        Me.btn28.UseVisualStyleBackColor = False
        '
        'btn27
        '
        Me.btn27.BackColor = System.Drawing.Color.White
        Me.btn27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn27.Enabled = False
        Me.btn27.Location = New System.Drawing.Point(271, 168)
        Me.btn27.Name = "btn27"
        Me.btn27.Size = New System.Drawing.Size(55, 42)
        Me.btn27.TabIndex = 54
        Me.btn27.UseVisualStyleBackColor = False
        '
        'btn26
        '
        Me.btn26.BackColor = System.Drawing.Color.Black
        Me.btn26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn26.Enabled = False
        Me.btn26.Location = New System.Drawing.Point(222, 168)
        Me.btn26.Name = "btn26"
        Me.btn26.Size = New System.Drawing.Size(55, 42)
        Me.btn26.TabIndex = 53
        Me.btn26.UseVisualStyleBackColor = False
        '
        'btn25
        '
        Me.btn25.BackColor = System.Drawing.Color.White
        Me.btn25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn25.Enabled = False
        Me.btn25.Location = New System.Drawing.Point(21, 275)
        Me.btn25.Name = "btn25"
        Me.btn25.Size = New System.Drawing.Size(55, 42)
        Me.btn25.TabIndex = 52
        Me.btn25.UseVisualStyleBackColor = False
        '
        'btn24
        '
        Me.btn24.BackColor = System.Drawing.Color.White
        Me.btn24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn24.Enabled = False
        Me.btn24.Location = New System.Drawing.Point(528, 132)
        Me.btn24.Name = "btn24"
        Me.btn24.Size = New System.Drawing.Size(55, 42)
        Me.btn24.TabIndex = 44
        Me.btn24.UseVisualStyleBackColor = False
        '
        'btn23
        '
        Me.btn23.BackColor = System.Drawing.Color.Black
        Me.btn23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn23.Enabled = False
        Me.btn23.Location = New System.Drawing.Point(474, 132)
        Me.btn23.Name = "btn23"
        Me.btn23.Size = New System.Drawing.Size(55, 42)
        Me.btn23.TabIndex = 43
        Me.btn23.UseVisualStyleBackColor = False
        '
        'btn22
        '
        Me.btn22.BackColor = System.Drawing.Color.White
        Me.btn22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn22.Enabled = False
        Me.btn22.Location = New System.Drawing.Point(425, 132)
        Me.btn22.Name = "btn22"
        Me.btn22.Size = New System.Drawing.Size(55, 42)
        Me.btn22.TabIndex = 42
        Me.btn22.UseVisualStyleBackColor = False
        '
        'btn21
        '
        Me.btn21.BackColor = System.Drawing.Color.Black
        Me.btn21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn21.Enabled = False
        Me.btn21.Location = New System.Drawing.Point(374, 132)
        Me.btn21.Name = "btn21"
        Me.btn21.Size = New System.Drawing.Size(55, 42)
        Me.btn21.TabIndex = 41
        Me.btn21.UseVisualStyleBackColor = False
        '
        'btn20
        '
        Me.btn20.BackColor = System.Drawing.Color.White
        Me.btn20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn20.Enabled = False
        Me.btn20.Location = New System.Drawing.Point(322, 132)
        Me.btn20.Name = "btn20"
        Me.btn20.Size = New System.Drawing.Size(55, 42)
        Me.btn20.TabIndex = 40
        Me.btn20.UseVisualStyleBackColor = False
        '
        'btn19
        '
        Me.btn19.BackColor = System.Drawing.Color.Black
        Me.btn19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn19.Enabled = False
        Me.btn19.Location = New System.Drawing.Point(273, 132)
        Me.btn19.Name = "btn19"
        Me.btn19.Size = New System.Drawing.Size(55, 42)
        Me.btn19.TabIndex = 39
        Me.btn19.UseVisualStyleBackColor = False
        '
        'btn18
        '
        Me.btn18.BackColor = System.Drawing.Color.White
        Me.btn18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn18.Enabled = False
        Me.btn18.Location = New System.Drawing.Point(221, 132)
        Me.btn18.Name = "btn18"
        Me.btn18.Size = New System.Drawing.Size(55, 42)
        Me.btn18.TabIndex = 37
        Me.btn18.UseVisualStyleBackColor = False
        '
        'btn17
        '
        Me.btn17.BackColor = System.Drawing.Color.Black
        Me.btn17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn17.Enabled = False
        Me.btn17.Location = New System.Drawing.Point(21, 239)
        Me.btn17.Name = "btn17"
        Me.btn17.Size = New System.Drawing.Size(55, 42)
        Me.btn17.TabIndex = 36
        Me.btn17.Text = "Button1"
        Me.btn17.UseVisualStyleBackColor = False
        '
        'btn48
        '
        Me.btn48.BackColor = System.Drawing.Color.Black
        Me.btn48.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn48.Enabled = False
        Me.btn48.Location = New System.Drawing.Point(528, 239)
        Me.btn48.Name = "btn48"
        Me.btn48.Size = New System.Drawing.Size(55, 42)
        Me.btn48.TabIndex = 98
        Me.btn48.Text = "Button1"
        Me.btn48.UseVisualStyleBackColor = False
        '
        'btn47
        '
        Me.btn47.BackColor = System.Drawing.Color.White
        Me.btn47.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn47.Enabled = False
        Me.btn47.Location = New System.Drawing.Point(476, 239)
        Me.btn47.Name = "btn47"
        Me.btn47.Size = New System.Drawing.Size(55, 42)
        Me.btn47.TabIndex = 90
        Me.btn47.UseVisualStyleBackColor = False
        '
        'btn46
        '
        Me.btn46.BackColor = System.Drawing.Color.Black
        Me.btn46.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn46.Enabled = False
        Me.btn46.Location = New System.Drawing.Point(424, 239)
        Me.btn46.Name = "btn46"
        Me.btn46.Size = New System.Drawing.Size(55, 42)
        Me.btn46.TabIndex = 89
        Me.btn46.UseVisualStyleBackColor = False
        '
        'btn45
        '
        Me.btn45.BackColor = System.Drawing.Color.White
        Me.btn45.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn45.Enabled = False
        Me.btn45.Location = New System.Drawing.Point(375, 239)
        Me.btn45.Name = "btn45"
        Me.btn45.Size = New System.Drawing.Size(55, 42)
        Me.btn45.TabIndex = 88
        Me.btn45.UseVisualStyleBackColor = False
        '
        'btn44
        '
        Me.btn44.BackColor = System.Drawing.Color.Black
        Me.btn44.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn44.Enabled = False
        Me.btn44.Location = New System.Drawing.Point(324, 239)
        Me.btn44.Name = "btn44"
        Me.btn44.Size = New System.Drawing.Size(55, 42)
        Me.btn44.TabIndex = 87
        Me.btn44.UseVisualStyleBackColor = False
        '
        'btn43
        '
        Me.btn43.BackColor = System.Drawing.Color.White
        Me.btn43.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn43.Enabled = False
        Me.btn43.Location = New System.Drawing.Point(272, 239)
        Me.btn43.Name = "btn43"
        Me.btn43.Size = New System.Drawing.Size(55, 42)
        Me.btn43.TabIndex = 86
        Me.btn43.UseVisualStyleBackColor = False
        '
        'btn42
        '
        Me.btn42.BackColor = System.Drawing.Color.Black
        Me.btn42.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn42.Enabled = False
        Me.btn42.Location = New System.Drawing.Point(223, 239)
        Me.btn42.Name = "btn42"
        Me.btn42.Size = New System.Drawing.Size(55, 42)
        Me.btn42.TabIndex = 85
        Me.btn42.UseVisualStyleBackColor = False
        '
        'btn41
        '
        Me.btn41.BackColor = System.Drawing.Color.White
        Me.btn41.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn41.Enabled = False
        Me.btn41.Location = New System.Drawing.Point(22, 346)
        Me.btn41.Name = "btn41"
        Me.btn41.Size = New System.Drawing.Size(55, 42)
        Me.btn41.TabIndex = 84
        Me.btn41.UseVisualStyleBackColor = False
        '
        'btn40
        '
        Me.btn40.BackColor = System.Drawing.Color.White
        Me.btn40.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn40.Enabled = False
        Me.btn40.Location = New System.Drawing.Point(529, 203)
        Me.btn40.Name = "btn40"
        Me.btn40.Size = New System.Drawing.Size(55, 42)
        Me.btn40.TabIndex = 76
        Me.btn40.UseVisualStyleBackColor = False
        '
        'btn39
        '
        Me.btn39.BackColor = System.Drawing.Color.Black
        Me.btn39.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn39.Enabled = False
        Me.btn39.Location = New System.Drawing.Point(475, 203)
        Me.btn39.Name = "btn39"
        Me.btn39.Size = New System.Drawing.Size(55, 42)
        Me.btn39.TabIndex = 75
        Me.btn39.UseVisualStyleBackColor = False
        '
        'btn38
        '
        Me.btn38.BackColor = System.Drawing.Color.White
        Me.btn38.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn38.Enabled = False
        Me.btn38.Location = New System.Drawing.Point(426, 203)
        Me.btn38.Name = "btn38"
        Me.btn38.Size = New System.Drawing.Size(55, 42)
        Me.btn38.TabIndex = 74
        Me.btn38.UseVisualStyleBackColor = False
        '
        'btn37
        '
        Me.btn37.BackColor = System.Drawing.Color.Black
        Me.btn37.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn37.Enabled = False
        Me.btn37.Location = New System.Drawing.Point(375, 203)
        Me.btn37.Name = "btn37"
        Me.btn37.Size = New System.Drawing.Size(55, 42)
        Me.btn37.TabIndex = 73
        Me.btn37.UseVisualStyleBackColor = False
        '
        'btn36
        '
        Me.btn36.BackColor = System.Drawing.Color.White
        Me.btn36.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn36.Enabled = False
        Me.btn36.Location = New System.Drawing.Point(323, 203)
        Me.btn36.Name = "btn36"
        Me.btn36.Size = New System.Drawing.Size(55, 42)
        Me.btn36.TabIndex = 72
        Me.btn36.UseVisualStyleBackColor = False
        '
        'btn35
        '
        Me.btn35.BackColor = System.Drawing.Color.Black
        Me.btn35.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn35.Enabled = False
        Me.btn35.Location = New System.Drawing.Point(274, 203)
        Me.btn35.Name = "btn35"
        Me.btn35.Size = New System.Drawing.Size(55, 42)
        Me.btn35.TabIndex = 71
        Me.btn35.UseVisualStyleBackColor = False
        '
        'btn33
        '
        Me.btn33.BackColor = System.Drawing.Color.Black
        Me.btn33.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn33.Enabled = False
        Me.btn33.Location = New System.Drawing.Point(22, 310)
        Me.btn33.Name = "btn33"
        Me.btn33.Size = New System.Drawing.Size(55, 42)
        Me.btn33.TabIndex = 68
        Me.btn33.Text = "Button1"
        Me.btn33.UseVisualStyleBackColor = False
        '
        'btn64
        '
        Me.btn64.BackColor = System.Drawing.Color.Black
        Me.btn64.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn64.Enabled = False
        Me.btn64.Location = New System.Drawing.Point(528, 311)
        Me.btn64.Name = "btn64"
        Me.btn64.Size = New System.Drawing.Size(55, 42)
        Me.btn64.TabIndex = 130
        Me.btn64.Text = "Button1"
        Me.btn64.UseVisualStyleBackColor = False
        '
        'btn63
        '
        Me.btn63.BackColor = System.Drawing.Color.White
        Me.btn63.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn63.Enabled = False
        Me.btn63.Location = New System.Drawing.Point(476, 311)
        Me.btn63.Name = "btn63"
        Me.btn63.Size = New System.Drawing.Size(55, 42)
        Me.btn63.TabIndex = 122
        Me.btn63.UseVisualStyleBackColor = False
        '
        'btn62
        '
        Me.btn62.BackColor = System.Drawing.Color.Black
        Me.btn62.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn62.Enabled = False
        Me.btn62.Location = New System.Drawing.Point(424, 311)
        Me.btn62.Name = "btn62"
        Me.btn62.Size = New System.Drawing.Size(55, 42)
        Me.btn62.TabIndex = 121
        Me.btn62.UseVisualStyleBackColor = False
        '
        'btn61
        '
        Me.btn61.BackColor = System.Drawing.Color.White
        Me.btn61.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn61.Enabled = False
        Me.btn61.Location = New System.Drawing.Point(375, 311)
        Me.btn61.Name = "btn61"
        Me.btn61.Size = New System.Drawing.Size(55, 42)
        Me.btn61.TabIndex = 120
        Me.btn61.UseVisualStyleBackColor = False
        '
        'btn60
        '
        Me.btn60.BackColor = System.Drawing.Color.Black
        Me.btn60.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn60.Enabled = False
        Me.btn60.Location = New System.Drawing.Point(324, 311)
        Me.btn60.Name = "btn60"
        Me.btn60.Size = New System.Drawing.Size(55, 42)
        Me.btn60.TabIndex = 119
        Me.btn60.UseVisualStyleBackColor = False
        '
        'btn59
        '
        Me.btn59.BackColor = System.Drawing.Color.White
        Me.btn59.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn59.Enabled = False
        Me.btn59.Location = New System.Drawing.Point(272, 311)
        Me.btn59.Name = "btn59"
        Me.btn59.Size = New System.Drawing.Size(55, 42)
        Me.btn59.TabIndex = 118
        Me.btn59.UseVisualStyleBackColor = False
        '
        'btn58
        '
        Me.btn58.BackColor = System.Drawing.Color.Black
        Me.btn58.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn58.Enabled = False
        Me.btn58.Location = New System.Drawing.Point(223, 311)
        Me.btn58.Name = "btn58"
        Me.btn58.Size = New System.Drawing.Size(55, 42)
        Me.btn58.TabIndex = 117
        Me.btn58.UseVisualStyleBackColor = False
        '
        'btn57
        '
        Me.btn57.BackColor = System.Drawing.Color.White
        Me.btn57.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn57.Enabled = False
        Me.btn57.Location = New System.Drawing.Point(22, 418)
        Me.btn57.Name = "btn57"
        Me.btn57.Size = New System.Drawing.Size(55, 42)
        Me.btn57.TabIndex = 116
        Me.btn57.UseVisualStyleBackColor = False
        '
        'btn56
        '
        Me.btn56.BackColor = System.Drawing.Color.White
        Me.btn56.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn56.Enabled = False
        Me.btn56.Location = New System.Drawing.Point(529, 275)
        Me.btn56.Name = "btn56"
        Me.btn56.Size = New System.Drawing.Size(55, 42)
        Me.btn56.TabIndex = 108
        Me.btn56.UseVisualStyleBackColor = False
        '
        'btn55
        '
        Me.btn55.BackColor = System.Drawing.Color.Black
        Me.btn55.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn55.Enabled = False
        Me.btn55.Location = New System.Drawing.Point(475, 275)
        Me.btn55.Name = "btn55"
        Me.btn55.Size = New System.Drawing.Size(55, 42)
        Me.btn55.TabIndex = 107
        Me.btn55.UseVisualStyleBackColor = False
        '
        'btn54
        '
        Me.btn54.BackColor = System.Drawing.Color.White
        Me.btn54.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn54.Enabled = False
        Me.btn54.Location = New System.Drawing.Point(426, 275)
        Me.btn54.Name = "btn54"
        Me.btn54.Size = New System.Drawing.Size(55, 42)
        Me.btn54.TabIndex = 106
        Me.btn54.UseVisualStyleBackColor = False
        '
        'btn53
        '
        Me.btn53.BackColor = System.Drawing.Color.Black
        Me.btn53.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn53.Enabled = False
        Me.btn53.Location = New System.Drawing.Point(375, 275)
        Me.btn53.Name = "btn53"
        Me.btn53.Size = New System.Drawing.Size(55, 42)
        Me.btn53.TabIndex = 105
        Me.btn53.UseVisualStyleBackColor = False
        '
        'btn52
        '
        Me.btn52.BackColor = System.Drawing.Color.White
        Me.btn52.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn52.Enabled = False
        Me.btn52.Location = New System.Drawing.Point(323, 275)
        Me.btn52.Name = "btn52"
        Me.btn52.Size = New System.Drawing.Size(55, 42)
        Me.btn52.TabIndex = 104
        Me.btn52.UseVisualStyleBackColor = False
        '
        'btn51
        '
        Me.btn51.BackColor = System.Drawing.Color.Black
        Me.btn51.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn51.Enabled = False
        Me.btn51.Location = New System.Drawing.Point(274, 275)
        Me.btn51.Name = "btn51"
        Me.btn51.Size = New System.Drawing.Size(55, 42)
        Me.btn51.TabIndex = 103
        Me.btn51.UseVisualStyleBackColor = False
        '
        'btn50
        '
        Me.btn50.BackColor = System.Drawing.Color.White
        Me.btn50.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn50.Enabled = False
        Me.btn50.Location = New System.Drawing.Point(22, 381)
        Me.btn50.Name = "btn50"
        Me.btn50.Size = New System.Drawing.Size(55, 42)
        Me.btn50.TabIndex = 101
        Me.btn50.UseVisualStyleBackColor = False
        '
        'btn34
        '
        Me.btn34.BackColor = System.Drawing.Color.White
        Me.btn34.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn34.Enabled = False
        Me.btn34.Location = New System.Drawing.Point(222, 203)
        Me.btn34.Name = "btn34"
        Me.btn34.Size = New System.Drawing.Size(55, 42)
        Me.btn34.TabIndex = 69
        Me.btn34.UseVisualStyleBackColor = False
        '
        'btn1
        '
        Me.btn1.BackColor = System.Drawing.Color.Black
        Me.btn1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn1.Enabled = False
        Me.btn1.Location = New System.Drawing.Point(21, 60)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(60, 60)
        Me.btn1.TabIndex = 2
        Me.btn1.Text = "Button1"
        Me.btn1.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(714, 470)
        Me.Controls.Add(Me.btn64)
        Me.Controls.Add(Me.btn63)
        Me.Controls.Add(Me.btn62)
        Me.Controls.Add(Me.btn61)
        Me.Controls.Add(Me.btn60)
        Me.Controls.Add(Me.btn59)
        Me.Controls.Add(Me.btn58)
        Me.Controls.Add(Me.btn57)
        Me.Controls.Add(Me.btn56)
        Me.Controls.Add(Me.btn55)
        Me.Controls.Add(Me.btn54)
        Me.Controls.Add(Me.btn53)
        Me.Controls.Add(Me.btn52)
        Me.Controls.Add(Me.btn51)
        Me.Controls.Add(Me.btn50)
        Me.Controls.Add(Me.btn48)
        Me.Controls.Add(Me.btn47)
        Me.Controls.Add(Me.btn46)
        Me.Controls.Add(Me.btn45)
        Me.Controls.Add(Me.btn44)
        Me.Controls.Add(Me.btn43)
        Me.Controls.Add(Me.btn42)
        Me.Controls.Add(Me.btn41)
        Me.Controls.Add(Me.btn40)
        Me.Controls.Add(Me.btn39)
        Me.Controls.Add(Me.btn38)
        Me.Controls.Add(Me.btn37)
        Me.Controls.Add(Me.btn36)
        Me.Controls.Add(Me.btn35)
        Me.Controls.Add(Me.btn34)
        Me.Controls.Add(Me.btn33)
        Me.Controls.Add(Me.btn32)
        Me.Controls.Add(Me.btn31)
        Me.Controls.Add(Me.btn30)
        Me.Controls.Add(Me.btn29)
        Me.Controls.Add(Me.btn28)
        Me.Controls.Add(Me.btn27)
        Me.Controls.Add(Me.btn26)
        Me.Controls.Add(Me.btn25)
        Me.Controls.Add(Me.btn24)
        Me.Controls.Add(Me.btn23)
        Me.Controls.Add(Me.btn22)
        Me.Controls.Add(Me.btn21)
        Me.Controls.Add(Me.btn20)
        Me.Controls.Add(Me.btn19)
        Me.Controls.Add(Me.btn18)
        Me.Controls.Add(Me.btn17)
        Me.Controls.Add(Me.btn16)
        Me.Controls.Add(Me.btn15)
        Me.Controls.Add(Me.btn14)
        Me.Controls.Add(Me.btn13)
        Me.Controls.Add(Me.btn12)
        Me.Controls.Add(Me.btn11)
        Me.Controls.Add(Me.btn10)
        Me.Controls.Add(Me.btn9)
        Me.Controls.Add(Me.pb8)
        Me.Controls.Add(Me.pb7)
        Me.Controls.Add(Me.pb6)
        Me.Controls.Add(Me.pb5)
        Me.Controls.Add(Me.pb4)
        Me.Controls.Add(Me.pb3)
        Me.Controls.Add(Me.pb2)
        Me.Controls.Add(Me.btn8)
        Me.Controls.Add(Me.btn7)
        Me.Controls.Add(Me.btn6)
        Me.Controls.Add(Me.btn5)
        Me.Controls.Add(Me.btn4)
        Me.Controls.Add(Me.btn3)
        Me.Controls.Add(Me.pb1)
        Me.Controls.Add(Me.btn2)
        Me.Controls.Add(Me.btn1)
        Me.Controls.Add(Me.mnuCheckers)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.MainMenuStrip = Me.mnuCheckers
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.mnuCheckers.ResumeLayout(False)
        Me.mnuCheckers.PerformLayout()
        CType(Me.pb1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents mnuCheckers As MenuStrip
    Friend WithEvents mnuFile As ToolStripMenuItem
    Friend WithEvents mnuClose As ToolStripMenuItem
    Friend WithEvents btn2 As Button
    Friend WithEvents pb1 As PictureBox
    Friend WithEvents btn3 As Button
    Friend WithEvents btn4 As Button
    Friend WithEvents btn5 As Button
    Friend WithEvents btn6 As Button
    Friend WithEvents btn7 As Button
    Friend WithEvents btn8 As Button
    Friend WithEvents pb2 As PictureBox
    Friend WithEvents pb3 As PictureBox
    Friend WithEvents pb4 As PictureBox
    Friend WithEvents pb5 As PictureBox
    Friend WithEvents pb6 As PictureBox
    Friend WithEvents pb7 As PictureBox
    Friend WithEvents pb8 As PictureBox
    Friend WithEvents btn15 As Button
    Friend WithEvents btn14 As Button
    Friend WithEvents btn13 As Button
    Friend WithEvents btn12 As Button
    Friend WithEvents btn11 As Button
    Friend WithEvents btn10 As Button
    Friend WithEvents btn9 As Button
    Friend WithEvents btn16 As Button
    Friend WithEvents btn32 As Button
    Friend WithEvents btn31 As Button
    Friend WithEvents btn30 As Button
    Friend WithEvents btn29 As Button
    Friend WithEvents btn28 As Button
    Friend WithEvents btn27 As Button
    Friend WithEvents btn26 As Button
    Friend WithEvents btn25 As Button
    Friend WithEvents btn24 As Button
    Friend WithEvents btn23 As Button
    Friend WithEvents btn22 As Button
    Friend WithEvents btn21 As Button
    Friend WithEvents btn20 As Button
    Friend WithEvents btn19 As Button
    Friend WithEvents btn18 As Button
    Friend WithEvents btn17 As Button
    Friend WithEvents btn48 As Button
    Friend WithEvents btn47 As Button
    Friend WithEvents btn46 As Button
    Friend WithEvents btn45 As Button
    Friend WithEvents btn44 As Button
    Friend WithEvents btn43 As Button
    Friend WithEvents btn42 As Button
    Friend WithEvents btn41 As Button
    Friend WithEvents btn40 As Button
    Friend WithEvents btn39 As Button
    Friend WithEvents btn38 As Button
    Friend WithEvents btn37 As Button
    Friend WithEvents btn36 As Button
    Friend WithEvents btn35 As Button
    Friend WithEvents btn33 As Button
    Friend WithEvents btn64 As Button
    Friend WithEvents btn63 As Button
    Friend WithEvents btn62 As Button
    Friend WithEvents btn61 As Button
    Friend WithEvents btn60 As Button
    Friend WithEvents btn59 As Button
    Friend WithEvents btn58 As Button
    Friend WithEvents btn57 As Button
    Friend WithEvents btn56 As Button
    Friend WithEvents btn55 As Button
    Friend WithEvents btn54 As Button
    Friend WithEvents btn53 As Button
    Friend WithEvents btn52 As Button
    Friend WithEvents btn51 As Button
    Friend WithEvents btn50 As Button
    Friend WithEvents mnuStart As ToolStripMenuItem
    Friend WithEvents btn34 As Button
    Friend WithEvents btn1 As Button
End Class
