﻿Public Class Form1
    Shared args As String
    Private Sub mnuClose_Click(sender As Object, e As EventArgs) Handles mnuClose.Click
        End
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim pb1 As CustomPictureBox
        pb1.BackColor = Color.Black
        pb1.Size = New Size(60, 60)
        pb1.Location = New Point(20, 60)
        Dim pb2 As CustomPictureBox
        pb2.BackColor = Color.White
        pb2.Size = New Size(60, 60)
        pb2.Location = New Point(80, 60)
        Dim pb3 As CustomPictureBox
        Dim pb4 As CustomPictureBox
        Dim pb5 As CustomPictureBox
        Dim pb6 As CustomPictureBox
        Dim pb7 As CustomPictureBox
        Dim pb8 As CustomPictureBox
        Dim pb9 As CustomPictureBox
        pb9.BackColor = Color.White
        pb9.Size = New Size(60, 60)
        pb9.Location = New Point(20, 120)
        Dim pb10 As CustomPictureBox
        Dim pb11 As CustomPictureBox
        Dim pb12 As CustomPictureBox
        Dim pb13 As CustomPictureBox
        Dim pb14 As CustomPictureBox
        Dim pb15 As CustomPictureBox
        Dim pb16 As CustomPictureBox
        Dim pb17 As CustomPictureBox
        Dim pb18 As CustomPictureBox
        Dim pb19 As CustomPictureBox
        Dim pb20 As CustomPictureBox
        Dim pb21 As CustomPictureBox
        Dim pb22 As CustomPictureBox
        Dim pb23 As CustomPictureBox
        Dim pb24 As CustomPictureBox
        Dim pb25 As CustomPictureBox
        Dim pb26 As CustomPictureBox
        Dim pb27 As CustomPictureBox
        Dim pb28 As CustomPictureBox
        Dim pb29 As CustomPictureBox
        Dim pb30 As CustomPictureBox
        Dim pb31 As CustomPictureBox
        Dim pb32 As CustomPictureBox
        Dim pb33 As CustomPictureBox
        Dim pb34 As CustomPictureBox
        Dim pb35 As CustomPictureBox
        Dim pb36 As CustomPictureBox
        Dim pb37 As CustomPictureBox
        Dim pb38 As CustomPictureBox
        Dim pb39 As CustomPictureBox
        Dim pb40 As CustomPictureBox
        Dim pb41 As CustomPictureBox
        Dim pb42 As CustomPictureBox
        Dim pb43 As CustomPictureBox
        Dim pb44 As CustomPictureBox
        Dim pb45 As CustomPictureBox
        Dim pb46 As CustomPictureBox
        Dim pb47 As CustomPictureBox
        Dim pb48 As CustomPictureBox
        Dim pb49 As CustomPictureBox
        Dim pb50 As CustomPictureBox
        Dim pb51 As CustomPictureBox
        Dim pb52 As CustomPictureBox
        Dim pb53 As CustomPictureBox
        Dim pb54 As CustomPictureBox
        Dim pb55 As CustomPictureBox
        Dim pb56 As CustomPictureBox
        Dim pb57 As CustomPictureBox
        Dim pb58 As CustomPictureBox
        Dim pb59 As CustomPictureBox
        Dim pb60 As CustomPictureBox
        Dim pb61 As CustomPictureBox
        Dim pb62 As CustomPictureBox
        Dim pb63 As CustomPictureBox
        Dim pb64 As CustomPictureBox
    End Sub

    Private Sub mnuStart_Click(sender As Object, e As EventArgs) Handles mnuStart.Click
        RunJar("Driver.jar")
    End Sub

    Shared Sub RunJar(command As String, Optional arguments As String = "")
        args = args.Concat(arguments)
        Dim p As Process = New Process()
        Dim pi As ProcessStartInfo = New ProcessStartInfo()
        pi.Arguments = " -jar " + command + " " + args
        'javaw instead of java so that a console window does not pop up
        pi.FileName = "javaw.exe"
        p.StartInfo = pi
        p.Start()
    End Sub

    Private Sub Form1_Click(sender As Object, e As EventArgs) Handles MyBase.Click

    End Sub

    Shared sngRow1 As Single = -1
    Shared sngRow2 As Single = -1
    Shared sngCol1 As Single = -1
    Shared sngCol2 As Single = -1

    Private Sub pb1_Click(sender As Object, e As EventArgs) Handles pb1.Click
        If sngRow1 = -1 Then
            sngRow1 = 0
            sngCol1 = 0
        Else
            sngRow2 = 0
            sngCol2 = 0
            If Confirm() = True Then
                args = String.Concat(args, " ", sngRow1, " ", sngCol1, " ", sngRow2, " ", sngCol2)
                RunJar("Driver.jar", args)
            End If
        End If
    End Sub

    Shared Function Confirm() As Boolean
        Dim sngConfirm As Boolean = MsgBox("Do you want to move these pieces?", vbOKCancel)
        Return sngConfirm
    End Function

    Public Enum Row
        zero = 0
        one = 1
        two = 2
        three = 3
        four = 4
        five = 5
        six = 6
        seven = 7
    End Enum

End Class
